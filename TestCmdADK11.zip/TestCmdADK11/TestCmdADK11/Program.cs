﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace TestCmdADK11
{
    internal class Program
    {
       
        static async Task Main(string[] args)
        {
            Console.WriteLine("Executing command:");
            Console.WriteLine("Dism /Mount-Image /ImageFile:\"C:\\WinPE_amd64\\media\\sources\\boot.wim\" /Index:1 /MountDir:\"C:\\WinPE_amd64\\mount\"");
            Console.WriteLine("Please waiting for result ...");

            string command = "/Mount-Image /ImageFile:\"\"C:\\WinPE_amd64\\media\\sources\\boot.wim\"\" /Index:1 /MountDir:\"\"C:\\WinPE_amd64\\mount\"\"";
            
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = "C:\\Program Files (x86)\\Windows Kits\\10\\Assessment and Deployment Kit\\Deployment Tools\\DandISetEnv.bat",
                Arguments = " & Dism " + command,
                UseShellExecute = false,
                StandardOutputEncoding = Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage),
                RedirectStandardError = true,
                RedirectStandardOutput = true
            };

            process.StartInfo = startInfo;
            await Task.Run(() => process.Start());

            // Read the output
            string output = await process.StandardOutput.ReadToEndAsync();
            process.WaitForExit();
            Console.WriteLine(output);

            Console.WriteLine("Executing command:");
            Console.WriteLine("Dism /Image:\"C:\\WinPE_amd64\\mount\" /Add-Driver /driver:\"D:\\Drivers\" /Recurse");
            Console.WriteLine("Please waiting for result ...");

            command = "/Image:\"\"C:\\WinPE_amd64\\mount\"\" /Add-Driver /driver:\"\"D:\\Drivers\"\" /Recurse";
            startInfo.Arguments = "& Dism" + command;
            await Task.Run(() => process.Start());

            // Read the output
            output = await process.StandardOutput.ReadToEndAsync();
            process.WaitForExit();
            Console.WriteLine(output);

            Console.WriteLine("Executing command:");
            Console.WriteLine("Dism /Unmount-Image /MountDir:\"C:\\WinPE_amd64\\mount\" /Discard");
            Console.WriteLine("Please waiting for result ...");

            command = "/Unmount-Image /MountDir:\"\"C:\\WinPE_amd64\\mount\"\" /Discard";
            startInfo.Arguments = "& Dism" + command;
            await Task.Run(() => process.Start());

            // Read the output
            output = await process.StandardOutput.ReadToEndAsync();
            process.WaitForExit();
            Console.WriteLine(output);

            Console.WriteLine("Press Enter to exit windows console");
            Console.ReadKey();
            process.Close();
        }
    }
}
