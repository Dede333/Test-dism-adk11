﻿Imports System.Threading

Module Module1
    Sub Main()

        ' This code is use to fix a specific error of dism (0xc1510114)
        ' ADK 11, a valide WinPE_amd64 folder create with copype command,
        ' a folder d:\drivers (or change hard code) with drivers are require and check if this is right
        ' for ADK 10, you can use Dism-GUI VB#

        Dim ProcessCMD As New ProcessStartInfo
        Dim myProcess As Process

        ProcessCMD.FileName = "cmd.exe"                         ' execute cmd process
        ProcessCMD.RedirectStandardError = False
        ProcessCMD.RedirectStandardInput = True                 ' redirect input of child process (cmd console)
        ProcessCMD.RedirectStandardOutput = False

        ' fix environment of ADK11 to use the new dism and /k for no cmd console close
        ProcessCMD.Arguments = "/k ""C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\DandISetEnv.bat"""

        ProcessCMD.UseShellExecute = False                      ' no shell
        ProcessCMD.WindowStyle = ProcessWindowStyle.Maximized
        ProcessCMD.CreateNoWindow = False                       ' false for retreive output console from child cmd process cmd

        myProcess = Process.Start(ProcessCMD)                   ' start child cmd process
        Thread.Sleep(100)                                       ' wait 100ms

        Console.WriteLine("Mount image, add some drivers to image, unmount image, please wait and press Enter to quit...")
        myProcess.StandardInput.WriteLine("Dism /Mount-Image /ImageFile:""C:\WinPE_amd64\media\sources\boot.wim"" /Index:1 /MountDir:""C:\WinPE_amd64\mount""")

        myProcess.StandardInput.WriteLine("Dism.exe /Image:""C:\WinPE_amd64\mount"" /Add-Driver /driver:""D:\Drivers"" /Recurse")

        myProcess.StandardInput.WriteLine("Dism.exe /Unmount-Image /MountDir:""C:\WinPE_amd64\mount"" /Discard")

        Console.ReadKey()
    End Sub

End Module
